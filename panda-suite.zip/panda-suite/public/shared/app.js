// shared/app.js
// Helper functions shared by every Panda Life / Panda Fin agent page.

/**
 * Calls a backend agent endpoint and returns parsed JSON.
 * Enforces a minimum delay so the "AI thinking" animation is visible —
 * this is purely cosmetic for the POC and can be removed later.
 */
async function callAgent(endpoint, payload, minDelay = 900) {
  const start = Date.now();
  const res = await fetch(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const data = await res.json();
  const elapsed = Date.now() - start;
  if (elapsed < minDelay) {
    await new Promise((r) => setTimeout(r, minDelay - elapsed));
  }
  return data;
}

/** Shows/hides a "thinking" element by id */
function setThinking(id, isThinking) {
  const el = document.getElementById(id);
  if (!el) return;
  el.classList.toggle('hidden', !isThinking);
}

/** Reads an uploaded file (txt/csv) as plain text and drops it into a textarea */
function wireFileDrop(dropId, inputId, textareaId, labelId) {
  const drop = document.getElementById(dropId);
  const input = document.getElementById(inputId);
  const textarea = document.getElementById(textareaId);
  const label = document.getElementById(labelId);

  drop.addEventListener('click', () => input.click());

  input.addEventListener('change', () => {
    const file = input.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      textarea.value = e.target.result;
      drop.classList.add('has-file');
      if (label) label.textContent = `✓ Loaded: ${file.name}`;
    };
    reader.readAsText(file);
  });
}

/** Builds a simple CSS-only bar chart into a container element */
function renderBars(containerId, labels, values) {
  const container = document.getElementById(containerId);
  if (!container) return;
  const max = Math.max(...values, 1);
  container.innerHTML = '';
  const wrap = document.createElement('div');
  wrap.className = 'bars';
  labels.forEach((label, i) => {
    const col = document.createElement('div');
    col.className = 'bar-col';
    const heightPct = Math.max(2, (values[i] / max) * 100);
    col.innerHTML = `
      <div style="font-size:10px;color:var(--muted);">${values[i]}</div>
      <div class="bar" style="height:${heightPct}%"></div>
      <div class="bar-label">${label}</div>
    `;
    wrap.appendChild(col);
  });
  container.appendChild(wrap);
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}
