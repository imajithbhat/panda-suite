// server.js
// Panda Life + Panda Fin — POC backend
// Built with Node.js built-in modules only — NO "npm install" required.

const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const store = require('./db/store');
const sopAgent = require('./agents/sopAgent');
const gxpAgent = require('./agents/gxpAgent');
const reportAgent = require('./agents/reportAgent');
const caseDocsAgent = require('./agents/caseDocsAgent');
const dataAgent = require('./agents/dataAgent');
const policyAgent = require('./agents/policyAgent');
const loanAgent = require('./agents/loanAgent');
const underwritingAgent = require('./agents/underwritingAgent');
const regulatoryAgent = require('./agents/regulatoryAgent');
const reconciliationAgent = require('./agents/reconciliationAgent');

const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, 'public');

const MIME_TYPES = {
  '.html': 'text/html',
  '.css': 'text/css',
  '.js': 'application/javascript',
  '.json': 'application/json',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon'
};

function sendJson(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(body)
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (chunk) => {
      data += chunk;
      if (data.length > 20 * 1024 * 1024) {
        reject(new Error('Payload too large'));
        req.destroy();
      }
    });
    req.on('end', () => {
      if (!data) return resolve({});
      try {
        resolve(JSON.parse(data));
      } catch (e) {
        resolve({});
      }
    });
    req.on('error', reject);
  });
}

function serveStatic(req, res, pathname) {
  let filePath = pathname;
  if (filePath === '/' || filePath.endsWith('/')) {
    filePath = filePath + 'index.html';
  }
  filePath = path.join(PUBLIC_DIR, filePath);

  // Prevent path traversal outside the public folder
  if (!filePath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403);
    return res.end('Forbidden');
  }

  fs.readFile(filePath, (err, content) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/html' });
      return res.end('<h1>404 — Not Found</h1><p><a href="/">Back to home</a></p>');
    }
    const ext = path.extname(filePath);
    res.writeHead(200, { 'Content-Type': MIME_TYPES[ext] || 'application/octet-stream' });
    res.end(content);
  });
}

async function handleApi(req, res, pathname) {
  const body = req.method === 'POST' ? await readBody(req) : {};

  // ---------- PANDA LIFE ----------
  if (pathname === '/api/life/sop/ask') {
    const result = sopAgent.answerQuestion(body.docText, body.question);
    store.insert('agent_runs', { agent: 'sop', input: body.question, output: result.answer });
    return sendJson(res, 200, result);
  }

  if (pathname === '/api/life/gxp/check') {
    const result = gxpAgent.checkDocument(body.docText);
    store.insert('agent_runs', { agent: 'gxp', input: 'document check', output: `score ${result.score}` });
    return sendJson(res, 200, result);
  }

  if (pathname === '/api/life/report/generate') {
    const result = reportAgent.generateReport(body.dataText);
    store.insert('agent_runs', { agent: 'report', input: 'report generation', output: result.summary || result.error });
    return sendJson(res, 200, result);
  }

  if (pathname === '/api/life/casedocs/extract') {
    const result = caseDocsAgent.extractCase(body.docText);
    store.insert('agent_runs', { agent: 'casedocs', input: 'case extraction', output: JSON.stringify(result.fields || {}) });
    return sendJson(res, 200, result);
  }

  if (pathname === '/api/life/data/query') {
    const result = dataAgent.answerQuery(body.csvText, body.question);
    store.insert('agent_runs', { agent: 'data', input: body.question, output: result.answer || result.error });
    return sendJson(res, 200, result);
  }

  // ---------- PANDA FIN ----------
  if (pathname === '/api/fin/policy/ask') {
    const result = policyAgent.answerQuestion(body.docText, body.question);
    store.insert('agent_runs', { agent: 'policy', input: body.question, output: result.answer });
    return sendJson(res, 200, result);
  }

  if (pathname === '/api/fin/loan/extract') {
    const result = loanAgent.extractApplication(body.docText);
    store.insert('agent_runs', { agent: 'loan', input: 'application extraction', output: JSON.stringify(result.fields || {}) });
    return sendJson(res, 200, result);
  }

  if (pathname === '/api/fin/underwriting/score') {
    const result = underwritingAgent.scoreApplicant(body);
    store.insert('agent_runs', { agent: 'underwriting', input: JSON.stringify(body), output: `${result.riskLevel} (${result.score})` });
    return sendJson(res, 200, result);
  }

  if (pathname === '/api/fin/regulatory/ask') {
    const result = regulatoryAgent.askRegulatory(body.question);
    store.insert('agent_runs', { agent: 'regulatory', input: body.question, output: result.answer });
    return sendJson(res, 200, result);
  }

  if (pathname === '/api/fin/reconciliation/compare') {
    const result = reconciliationAgent.reconcile(body.csvA, body.csvB);
    store.insert('reconciliation_results', { summary: result.summary || result.error });
    return sendJson(res, 200, result);
  }

  return sendJson(res, 404, { error: 'Unknown API endpoint' });
}

const server = http.createServer(async (req, res) => {
  const parsed = url.parse(req.url);
  const pathname = decodeURIComponent(parsed.pathname);

  try {
    if (pathname.startsWith('/api/')) {
      await handleApi(req, res, pathname);
    } else {
      serveStatic(req, res, pathname);
    }
  } catch (err) {
    console.error(err);
    sendJson(res, 500, { error: 'Server error', details: err.message });
  }
});

server.listen(PORT, () => {
  console.log('');
  console.log('  🐼  Panda Suite POC is running!');
  console.log(`  ➜  Open this in your browser: http://localhost:${PORT}`);
  console.log('');
});
