// db/store.js
// A tiny "database" built on plain JSON files.
// No external packages needed — works the moment Node.js is installed.

const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, 'data');

// Make sure the data folder + each table file exists
const TABLES = [
  'documents',
  'agent_runs',
  'chat_history',
  'reconciliation_results'
];

function ensureReady() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  TABLES.forEach((table) => {
    const file = path.join(DATA_DIR, `${table}.json`);
    if (!fs.existsSync(file)) fs.writeFileSync(file, '[]', 'utf8');
  });
}

function readTable(table) {
  ensureReady();
  const file = path.join(DATA_DIR, `${table}.json`);
  try {
    const raw = fs.readFileSync(file, 'utf8');
    return JSON.parse(raw || '[]');
  } catch (e) {
    return [];
  }
}

function writeTable(table, rows) {
  ensureReady();
  const file = path.join(DATA_DIR, `${table}.json`);
  fs.writeFileSync(file, JSON.stringify(rows, null, 2), 'utf8');
}

function insert(table, row) {
  const rows = readTable(table);
  const record = Object.assign(
    { id: Date.now() + '-' + Math.random().toString(36).slice(2, 8), created_at: new Date().toISOString() },
    row
  );
  rows.push(record);
  writeTable(table, rows);
  return record;
}

function all(table) {
  return readTable(table);
}

module.exports = { insert, all, ensureReady };
