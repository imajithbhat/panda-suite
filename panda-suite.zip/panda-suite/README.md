# Panda Suite — Panda Life + Panda Fin (Proof of Concept)

This is a working demo of two agentic AI products:
- **Panda Life** — 5 AI agents for Life Sciences
- **Panda Fin** — 5 AI agents for Financial Services

The "AI" in this POC is **simulated** (rule-based logic that behaves like an AI agent) so you can see and click through exactly how each feature will work — with **zero setup cost or API keys needed**. Every agent is built so the simulated logic can later be swapped for a real Claude API call in one clearly marked spot per file (look for `REAL-AI SWAP POINT` comments in the `agents/` folder).

---

## ✅ Step 1 — Install Node.js (one-time only)

This app needs **Node.js** to run (it's the engine, like how a PDF needs Adobe Reader).

1. Go to **https://nodejs.org**
2. Download the version marked **LTS** (Recommended)
3. Run the installer, click Next through the defaults

To check it worked, open:
- **Windows:** Command Prompt (search "cmd" in the Start menu)
- **Mac:** Terminal (search "Terminal" in Spotlight)

Type:
```
node -v
```
If you see a version number (e.g. `v20.11.0`), you're ready.

*(No other installs are needed — no npm install, no database software, nothing else.)*

---

## ✅ Step 2 — Run the app

1. Unzip the `panda-suite` folder you downloaded, anywhere on your computer (e.g. Desktop)
2. Open Command Prompt / Terminal
3. Navigate into the folder. Example:
   ```
   cd Desktop/panda-suite
   ```
4. Start the server:
   ```
   node server.js
   ```
5. You should see:
   ```
   🐼  Panda Suite POC is running!
   ➜  Open this in your browser: http://localhost:3000
   ```
6. Open your web browser and go to: **http://localhost:3000**

That's it — you'll land on the product selector where you can enter **Panda Life** or **Panda Fin**.

To stop the app later, go back to the Command Prompt / Terminal window and press `Ctrl + C`.

---

## 🗺️ What you can click through

### Panda Life
| Agent | Try this |
|---|---|
| SOP Agent | Ask "What is the cleaning procedure?" using the pre-loaded sample SOP |
| GxP Agent | Click "Run GxP Check" on the sample document to see the compliance score |
| Report Agent | Click "Generate Report" to see an AI-written summary of sample batch data |
| Case Docs Agent | Click "Extract Case Data" to see structured fields pulled from a sample case report |
| Data Agent | Ask "What is the average Yield_Percent?" about the sample dataset |

### Panda Fin
| Agent | Try this |
|---|---|
| Policy Assist | Ask "Is dental treatment covered?" using the pre-loaded sample policy |
| Loan Co-Pilot | Click "Auto-Fill Application" to see a loan form filled from a sample salary slip |
| Underwriting | Click "Run Underwriting Check" to get a risk score + reasoning |
| Regulatory | Ask "What are the KYC requirements?" |
| Reconciliation | Click "Run Reconciliation" to compare the two sample ledgers and see flagged mismatches |

You can also replace any sample text with your own — paste your own document/data into the text box, or click the upload box to load a `.txt` or `.csv` file.

---

## 📁 What's inside (in plain terms)

```
panda-suite/
├── server.js         → the "engine" that runs everything (just run this file)
├── agents/            → the "brain" of each AI agent (10 files, one per module)
├── public/             → everything you see in the browser
│   ├── panda-life/       → the 5 Life Sciences agent pages
│   ├── panda-fin/        → the 5 Financial Services agent pages
│   └── shared/           → shared design + code used by every page
├── db/                → where uploaded data & results get saved (plain files, no install needed)
└── README.md          → this file
```

---

## 🔁 Moving to real AI (Phase 3, later)

Every agent file inside `/agents` has a comment block like:

```js
// >>> REAL-AI SWAP POINT <<<
```

That marks exactly where the simulated logic can be replaced with a real call to the Claude API — nothing else in the app needs to change. This lets you show the working POC today, and upgrade the "brain" of any single agent later without rebuilding anything.

---

## ❓Troubleshooting

- **"node: command not found"** → Node.js isn't installed yet — see Step 1.
- **Port already in use** → Another program is using port 3000. Close it, or run `PORT=3001 node server.js` and open `http://localhost:3001` instead.
- **Page looks unstyled** → Make sure you're connected to the internet the first time you load it (fonts load from Google Fonts); everything else works fully offline.
