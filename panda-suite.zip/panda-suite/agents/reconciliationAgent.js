// agents/reconciliationAgent.js — Account Reconciliation Agent
// Compares two transaction ledgers (e.g. Bank vs Book) and explains
// mismatches.
//
// >>> REAL-AI SWAP POINT <<<
// Replace the matching heuristic with a Claude API call for fuzzy /
// semantic matching of descriptions, and richer discrepancy narratives.

function parseCsv(text) {
  const lines = text.trim().split('\n').map((l) => l.trim()).filter(Boolean);
  if (lines.length < 2) return { headers: [], rows: [] };
  const headers = lines[0].split(',').map((h) => h.trim());
  const rows = lines.slice(1).map((line) => {
    const cells = line.split(',').map((c) => c.trim());
    const obj = {};
    headers.forEach((h, i) => (obj[h] = cells[i] !== undefined ? cells[i] : ''));
    return obj;
  });
  return { headers, rows };
}

function findAmountKey(headers) {
  return headers.find((h) => /amount|value|amt/i.test(h)) || headers[headers.length - 1];
}
function findRefKey(headers) {
  return headers.find((h) => /ref|reference|id|txn/i.test(h));
}

function reconcile(csvA, csvB) {
  const bank = parseCsv(csvA);
  const book = parseCsv(csvB);

  if (bank.headers.length === 0 || book.headers.length === 0) {
    return { error: 'Both ledgers need a header row and at least one transaction row.' };
  }

  const amtKeyA = findAmountKey(bank.headers);
  const amtKeyB = findAmountKey(book.headers);
  const refKeyA = findRefKey(bank.headers);
  const refKeyB = findRefKey(book.headers);

  const matched = [];
  const unmatchedBank = [];
  const usedBookIndexes = new Set();

  bank.rows.forEach((bankRow) => {
    const bankAmt = parseFloat(bankRow[amtKeyA]);
    const bankRef = refKeyA ? bankRow[refKeyA] : null;

    let foundIndex = -1;

    // First try matching by reference number
    if (bankRef) {
      foundIndex = book.rows.findIndex(
        (bookRow, i) => !usedBookIndexes.has(i) && refKeyB && bookRow[refKeyB] === bankRef
      );
    }

    // Fall back to matching by exact amount
    if (foundIndex === -1) {
      foundIndex = book.rows.findIndex(
        (bookRow, i) => !usedBookIndexes.has(i) && parseFloat(bookRow[amtKeyB]) === bankAmt
      );
    }

    if (foundIndex !== -1) {
      usedBookIndexes.add(foundIndex);
      matched.push({ bank: bankRow, book: book.rows[foundIndex] });
    } else {
      // Look for a "close" amount match to explain a likely discrepancy
      const closeIndex = book.rows.findIndex((bookRow, i) => {
        if (usedBookIndexes.has(i)) return false;
        const diff = Math.abs(parseFloat(bookRow[amtKeyB]) - bankAmt);
        return diff > 0 && diff <= Math.max(1, Math.abs(bankAmt) * 0.02);
      });
      let explanation = 'No matching entry found in the book ledger — possible missing or duplicate entry.';
      if (closeIndex !== -1) {
        explanation = `A close amount match was found (possible rounding or fee difference of ${(
          parseFloat(book.rows[closeIndex][amtKeyB]) - bankAmt
        ).toFixed(2)}).`;
      }
      unmatchedBank.push({ row: bankRow, explanation });
    }
  });

  const unmatchedBook = book.rows
    .map((row, i) => ({ row, i }))
    .filter(({ i }) => !usedBookIndexes.has(i))
    .map(({ row }) => ({
      row,
      explanation: 'No matching entry found in the bank ledger — possible timing difference or unrecorded transaction.'
    }));

  return {
    summary: {
      totalBank: bank.rows.length,
      totalBook: book.rows.length,
      matchedCount: matched.length,
      unmatchedBankCount: unmatchedBank.length,
      unmatchedBookCount: unmatchedBook.length
    },
    matched,
    unmatchedBank,
    unmatchedBook
  };
}

module.exports = { reconcile };
