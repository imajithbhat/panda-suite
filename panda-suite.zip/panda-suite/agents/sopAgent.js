// agents/sopAgent.js — SOP Agent (partnership with Stepbio)
// Reads an SOP document and answers employee questions about it.
//
// >>> REAL-AI SWAP POINT <<<
// Replace the body of answerQuestion() with a call to the Claude API,
// passing `docText` as context and `question` as the user message.

const { splitParagraphs, bestMatch } = require('./_helpers');

function answerQuestion(docText, question) {
  if (!docText || !docText.trim()) {
    return {
      answer: "I don't have an SOP document loaded yet. Please upload or paste one first.",
      source: null,
      confidence: 0
    };
  }

  const paragraphs = splitParagraphs(docText);
  const { chunk, score } = bestMatch(question, paragraphs);

  if (!chunk || score === 0) {
    return {
      answer:
        "I couldn't find a section of this SOP that directly answers that. Try rephrasing, or check if this is covered in a related SOP.",
      source: null,
      confidence: 0
    };
  }

  const confidence = Math.min(95, 40 + score * 12);

  return {
    answer: `Based on the SOP document: ${chunk}`,
    source: chunk,
    confidence
  };
}

module.exports = { answerQuestion };
