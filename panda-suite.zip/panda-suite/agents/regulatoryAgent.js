// agents/regulatoryAgent.js — Regulatory Agent
// Answers compliance / regulatory questions from a small internal rule
// library and flags the applicable regulation.
//
// >>> REAL-AI SWAP POINT <<<
// Replace RULES + matching logic with a Claude API call (with retrieval
// over your real regulatory corpus, e.g. RBI/SEC/FATF/Basel documents).

const RULES = [
  {
    keywords: ['kyc', 'know your customer', 'identity verification'],
    regulation: 'KYC / Customer Due Diligence Guidelines',
    explanation:
      'Financial institutions must verify customer identity using government-issued ID and proof of address before onboarding, and re-verify periodically based on risk category.'
  },
  {
    keywords: ['aml', 'money laundering', 'suspicious transaction'],
    regulation: 'Anti-Money Laundering (AML) Regulations',
    explanation:
      'Institutions must monitor transactions for suspicious patterns, file Suspicious Transaction Reports (STRs), and maintain records for a minimum retention period (commonly 5 years).'
  },
  {
    keywords: ['capital', 'basel', 'capital adequacy'],
    regulation: 'Basel III Capital Adequacy Framework',
    explanation:
      'Banks must maintain a minimum Capital Adequacy Ratio (CAR), including a Common Equity Tier 1 buffer, to absorb losses and reduce systemic risk.'
  },
  {
    keywords: ['data protection', 'privacy', 'personal data'],
    regulation: 'Data Protection / Privacy Regulations',
    explanation:
      'Customer financial and personal data must be collected with consent, stored securely, and only used for the stated purpose, with breach notification obligations.'
  },
  {
    keywords: ['loan', 'lending', 'interest rate disclosure'],
    regulation: 'Fair Lending & Interest Rate Disclosure Rules',
    explanation:
      'Lenders must disclose the Annual Percentage Rate (APR), all fees, and repayment terms clearly to the borrower before agreement, and apply consistent underwriting criteria.'
  },
  {
    keywords: ['reconciliation', 'ledger', 'general ledger'],
    regulation: 'Financial Reporting & Reconciliation Standards',
    explanation:
      'Institutions must reconcile internal ledgers with external statements on a regular cadence (commonly daily or monthly) and document any discrepancies with a resolution trail.'
  }
];

function askRegulatory(question) {
  const lower = (question || '').toLowerCase();
  let best = null;
  let bestScore = 0;

  RULES.forEach((rule) => {
    const score = rule.keywords.filter((k) => lower.includes(k)).length;
    if (score > bestScore) {
      bestScore = score;
      best = rule;
    }
  });

  if (!best) {
    return {
      matched: false,
      answer:
        "I couldn't match this question to a regulation in the current rule library. In a full deployment, this would trigger a retrieval search across the full regulatory corpus."
    };
  }

  return {
    matched: true,
    regulation: best.regulation,
    answer: best.explanation
  };
}

module.exports = { askRegulatory };
