// agents/gxpAgent.js — GxP Agent
// Checks a document against common GxP documentation requirements
// and produces an audit-readiness checklist + compliance score.
//
// >>> REAL-AI SWAP POINT <<<
// Replace the keyword checklist below with a Claude API call that reasons
// over the full document against your real GxP checklist / SOP template.

const REQUIRED_ITEMS = [
  { key: 'purpose', label: 'Purpose / Objective section', patterns: ['purpose', 'objective'] },
  { key: 'scope', label: 'Scope defined', patterns: ['scope'] },
  { key: 'responsibility', label: 'Roles & Responsibilities listed', patterns: ['responsibilit'] },
  { key: 'procedure', label: 'Step-by-step Procedure', patterns: ['procedure', 'steps', 'instructions'] },
  { key: 'version', label: 'Version / Revision number', patterns: ['version', 'revision'] },
  { key: 'effective_date', label: 'Effective Date present', patterns: ['effective date', 'date issued'] },
  { key: 'approval', label: 'Approval / Sign-off section', patterns: ['approved by', 'approval', 'signature'] },
  { key: 'review', label: 'Periodic Review clause', patterns: ['review date', 'next review', 'periodic review'] }
];

function checkDocument(docText) {
  const lower = (docText || '').toLowerCase();

  const checklist = REQUIRED_ITEMS.map((item) => {
    const found = item.patterns.some((p) => lower.includes(p));
    return {
      label: item.label,
      status: found ? 'pass' : 'fail',
      note: found
        ? 'Detected in document.'
        : `Not found — GxP audits typically expect a clearly labeled "${item.label}" section.`
    };
  });

  const passCount = checklist.filter((c) => c.status === 'pass').length;
  const score = Math.round((passCount / checklist.length) * 100);

  let verdict = 'Not audit-ready';
  if (score >= 90) verdict = 'Audit-ready';
  else if (score >= 60) verdict = 'Minor gaps — review recommended';

  return { checklist, score, verdict };
}

module.exports = { checkDocument };
