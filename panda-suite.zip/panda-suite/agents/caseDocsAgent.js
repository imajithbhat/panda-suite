// agents/caseDocsAgent.js — Case Docs Agent
// Extracts structured fields from a case / adverse-event document and
// writes a short narrative summary.
//
// >>> REAL-AI SWAP POINT <<<
// Replace the regex extraction with a Claude API call using a structured
// extraction prompt (or tool call) against the real document.

const { extractField } = require('./_helpers');

function extractCase(docText) {
  if (!docText || !docText.trim()) {
    return { error: 'No case document provided.' };
  }

  const fields = {
    patientId: extractField(docText, ['patient id', 'subject id', 'case id']) || 'Not found',
    date: extractField(docText, ['date of event', 'event date', 'date']) || 'Not found',
    severity: extractField(docText, ['severity', 'seriousness']) || 'Not found',
    event: extractField(docText, ['event', 'adverse event', 'description']) || 'Not found',
    outcome: extractField(docText, ['outcome']) || 'Not found'
  };

  const narrative =
    `Case summary: ` +
    `Patient/Subject ${fields.patientId !== 'Not found' ? fields.patientId : '(unidentified)'} ` +
    `experienced an event${fields.event !== 'Not found' ? ` described as "${fields.event}"` : ''}` +
    `${fields.date !== 'Not found' ? ` on ${fields.date}` : ''}` +
    `${fields.severity !== 'Not found' ? `, classified as ${fields.severity} severity` : ''}` +
    `${fields.outcome !== 'Not found' ? `. Reported outcome: ${fields.outcome}.` : '.'}`;

  return { fields, narrative };
}

module.exports = { extractCase };
