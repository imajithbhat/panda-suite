// agents/dataAgent.js — Data Agent
// Lets a user ask plain-English questions about an uploaded CSV dataset.
//
// >>> REAL-AI SWAP POINT <<<
// Replace parseQuestion()'s pattern matching with a Claude API call that
// converts the question into a query plan (or writes/executes the analysis).

function parseCsv(text) {
  const lines = text.trim().split('\n').map((l) => l.trim()).filter(Boolean);
  if (lines.length < 2) return { headers: [], rows: [] };
  const headers = lines[0].split(',').map((h) => h.trim());
  const rows = lines.slice(1).map((line) => line.split(',').map((c) => c.trim()));
  return { headers, rows };
}

function findColumn(headers, question) {
  const lower = question.toLowerCase();
  return headers.find((h) => lower.includes(h.toLowerCase()));
}

function answerQuery(csvText, question) {
  const { headers, rows } = parseCsv(csvText);
  if (headers.length === 0) {
    return { error: 'Could not detect a table. Paste comma-separated data with a header row.' };
  }

  const col = findColumn(headers, question);
  const lowerQ = question.toLowerCase();

  if (!col) {
    return {
      answer: `I found ${rows.length} rows across columns: ${headers.join(', ')}. Try asking about one of these columns specifically, e.g. "What is the average ${headers[1] || headers[0]}?"`,
      chart: null
    };
  }

  const colIndex = headers.indexOf(col);
  const values = rows.map((r) => parseFloat(r[colIndex])).filter((v) => !isNaN(v));

  let answer;
  let opUsed = 'value';

  if (lowerQ.includes('average') || lowerQ.includes('mean')) {
    const avg = values.reduce((a, b) => a + b, 0) / values.length;
    answer = `The average ${col} is ${Math.round(avg * 100) / 100}.`;
    opUsed = 'average';
  } else if (lowerQ.includes('max') || lowerQ.includes('highest')) {
    answer = `The highest ${col} is ${Math.max(...values)}.`;
    opUsed = 'max';
  } else if (lowerQ.includes('min') || lowerQ.includes('lowest')) {
    answer = `The lowest ${col} is ${Math.min(...values)}.`;
    opUsed = 'min';
  } else if (lowerQ.includes('how many') || lowerQ.includes('count')) {
    answer = `There are ${rows.length} rows in this dataset.`;
    opUsed = 'count';
  } else if (lowerQ.includes('total') || lowerQ.includes('sum')) {
    const sum = values.reduce((a, b) => a + b, 0);
    answer = `The total ${col} is ${Math.round(sum * 100) / 100}.`;
    opUsed = 'sum';
  } else {
    answer = `Here's a breakdown of the "${col}" column across all ${rows.length} rows.`;
  }

  // Build simple chart data (first 12 rows) for visualization
  const chart = {
    labels: rows.slice(0, 12).map((r, i) => r[0] || `Row ${i + 1}`),
    values: rows.slice(0, 12).map((r) => parseFloat(r[colIndex]) || 0),
    column: col,
    op: opUsed
  };

  return { answer, chart };
}

module.exports = { answerQuery };
