// agents/loanAgent.js — Loan Application Co-Pilot Agent
// Extracts applicant fields from an uploaded ID / salary-slip style
// document and auto-fills a loan application form.
//
// >>> REAL-AI SWAP POINT <<<
// Replace the regex extraction with a Claude API structured-extraction
// call against the real (scanned/OCR'd) document.

const { extractField } = require('./_helpers');

function extractApplication(docText) {
  if (!docText || !docText.trim()) {
    return { error: 'No document provided.' };
  }

  const fields = {
    name: extractField(docText, ['name']) || '',
    dob: extractField(docText, ['date of birth', 'dob']) || '',
    idNumber: extractField(docText, ['id number', 'id no', 'passport no', 'aadhaar', 'pan']) || '',
    monthlyIncome: extractField(docText, ['monthly income', 'net salary', 'salary', 'income']) || '',
    employer: extractField(docText, ['employer', 'company name', 'organization']) || '',
    address: extractField(docText, ['address']) || ''
  };

  const filledCount = Object.values(fields).filter((v) => v).length;
  const completeness = Math.round((filledCount / Object.keys(fields).length) * 100);

  return { fields, completeness };
}

module.exports = { extractApplication };
