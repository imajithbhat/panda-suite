// agents/_helpers.js
// Small helpers shared by every agent file.

function splitParagraphs(text) {
  return text
    .split(/\n\s*\n|\r\n\r\n/)
    .map((p) => p.trim())
    .filter(Boolean);
}

function splitSentences(text) {
  return text
    .split(/(?<=[.!?])\s+/)
    .map((s) => s.trim())
    .filter(Boolean);
}

// naive keyword overlap scorer — used by SOP / Policy agents to find the
// most relevant paragraph for a question. This is the exact spot where a
// real AI model call would replace the scoring logic.
function bestMatch(question, chunks) {
  const qWords = question
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, '')
    .split(/\s+/)
    .filter((w) => w.length > 2);

  let best = { chunk: null, score: 0 };
  chunks.forEach((chunk) => {
    const lower = chunk.toLowerCase();
    let score = 0;
    qWords.forEach((w) => {
      if (lower.includes(w)) score += 1;
    });
    if (score > best.score) best = { chunk, score };
  });
  return best;
}

function extractField(text, labels) {
  for (const label of labels) {
    const re = new RegExp(label + '\\s*[:\\-]\\s*(.+)', 'i');
    const match = text.match(re);
    if (match) return match[1].split('\n')[0].trim();
  }
  return null;
}

module.exports = { splitParagraphs, splitSentences, bestMatch, extractField };
