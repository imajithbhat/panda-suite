// agents/reportAgent.js — Report Agent
// Turns a pasted data table (CSV-style) into a formatted report with an
// auto-written executive summary.
//
// >>> REAL-AI SWAP POINT <<<
// Replace buildSummary() with a Claude API call that writes the narrative
// summary from the computed stats (or directly from the raw data).

function parseCsv(text) {
  const lines = text.trim().split('\n').map((l) => l.trim()).filter(Boolean);
  if (lines.length < 2) return { headers: [], rows: [] };
  const headers = lines[0].split(',').map((h) => h.trim());
  const rows = lines.slice(1).map((line) => line.split(',').map((c) => c.trim()));
  return { headers, rows };
}

function computeStats(headers, rows) {
  return headers.map((header, colIndex) => {
    const values = rows.map((r) => parseFloat(r[colIndex])).filter((v) => !isNaN(v));
    if (values.length === 0) {
      return { column: header, type: 'text', count: rows.length };
    }
    const sum = values.reduce((a, b) => a + b, 0);
    const avg = sum / values.length;
    return {
      column: header,
      type: 'number',
      count: values.length,
      min: Math.min(...values),
      max: Math.max(...values),
      avg: Math.round(avg * 100) / 100
    };
  });
}

function buildSummary(headers, rows, stats) {
  const numeric = stats.filter((s) => s.type === 'number');
  let summary = `This report covers ${rows.length} record${rows.length === 1 ? '' : 's'} across ${headers.length} field${headers.length === 1 ? '' : 's'} (${headers.join(', ')}). `;

  if (numeric.length > 0) {
    summary += numeric
      .map((s) => `Average ${s.column} was ${s.avg} (range ${s.min}–${s.max}).`)
      .join(' ');
  } else {
    summary += 'No numeric columns were detected to summarize quantitatively.';
  }
  return summary;
}

function generateReport(dataText) {
  const { headers, rows } = parseCsv(dataText);
  if (headers.length === 0) {
    return { error: 'Could not detect a table. Paste comma-separated data with a header row.' };
  }
  const stats = computeStats(headers, rows);
  const summary = buildSummary(headers, rows, stats);
  return { headers, rows, stats, summary, generatedAt: new Date().toISOString() };
}

module.exports = { generateReport };
