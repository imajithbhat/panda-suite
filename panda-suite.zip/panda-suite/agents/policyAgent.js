// agents/policyAgent.js — Policy Assist Agent
// Answers questions about an uploaded policy document.
//
// >>> REAL-AI SWAP POINT <<<
// Replace the body of answerQuestion() with a Claude API call, passing
// `docText` as context and `question` as the user message.

const { splitParagraphs, bestMatch } = require('./_helpers');

function answerQuestion(docText, question) {
  if (!docText || !docText.trim()) {
    return {
      answer: "I don't have a policy document loaded yet. Please upload or paste one first.",
      source: null,
      confidence: 0
    };
  }

  const paragraphs = splitParagraphs(docText);
  const { chunk, score } = bestMatch(question, paragraphs);

  if (!chunk || score === 0) {
    return {
      answer:
        "I couldn't find a clause in this policy that directly answers that. Try rephrasing, or this may not be covered under this policy.",
      source: null,
      confidence: 0
    };
  }

  const confidence = Math.min(95, 40 + score * 12);

  return {
    answer: `According to the policy document: ${chunk}`,
    source: chunk,
    confidence
  };
}

module.exports = { answerQuestion };
