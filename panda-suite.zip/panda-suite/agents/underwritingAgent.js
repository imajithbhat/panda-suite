// agents/underwritingAgent.js — Underwriting Agent
// Produces a risk score + plain-English reasoning for a loan applicant.
//
// >>> REAL-AI SWAP POINT <<<
// Replace scoreApplicant() with a Claude API call that reasons over the
// full applicant profile (and any real credit bureau data) to produce
// the score and narrative explanation.

function scoreApplicant(applicant) {
  const income = parseFloat(applicant.monthlyIncome) || 0;
  const loanAmount = parseFloat(applicant.loanAmount) || 0;
  const creditYears = parseFloat(applicant.creditHistoryYears) || 0;
  const employmentYears = parseFloat(applicant.employmentYears) || 0;
  const existingDebt = parseFloat(applicant.existingMonthlyDebt) || 0;

  let points = 50;
  const reasons = [];

  // Debt-to-income
  const dti = income > 0 ? (existingDebt / income) * 100 : 100;
  if (dti < 20) {
    points += 15;
    reasons.push(`Low debt-to-income ratio (${dti.toFixed(0)}%) is a strong positive factor.`);
  } else if (dti < 40) {
    points += 5;
    reasons.push(`Moderate debt-to-income ratio (${dti.toFixed(0)}%).`);
  } else {
    points -= 15;
    reasons.push(`High debt-to-income ratio (${dti.toFixed(0)}%) increases risk.`);
  }

  // Loan-to-income multiple
  const loanToIncome = income > 0 ? loanAmount / (income * 12) : 999;
  if (loanToIncome < 2) {
    points += 15;
    reasons.push('Requested loan amount is well within annual income capacity.');
  } else if (loanToIncome < 4) {
    points += 5;
    reasons.push('Requested loan amount is moderately high relative to annual income.');
  } else {
    points -= 15;
    reasons.push('Requested loan amount is high relative to annual income.');
  }

  // Credit history
  if (creditYears >= 5) {
    points += 10;
    reasons.push('Long credit history supports predictability of repayment behavior.');
  } else if (creditYears >= 2) {
    points += 3;
    reasons.push('Moderate credit history length.');
  } else {
    points -= 10;
    reasons.push('Short credit history adds uncertainty.');
  }

  // Employment stability
  if (employmentYears >= 3) {
    points += 10;
    reasons.push('Stable employment history (3+ years).');
  } else {
    points -= 5;
    reasons.push('Shorter employment history may indicate income instability.');
  }

  points = Math.max(0, Math.min(100, points));

  let riskLevel = 'High';
  if (points >= 75) riskLevel = 'Low';
  else if (points >= 50) riskLevel = 'Medium';

  return {
    score: points,
    riskLevel,
    reasons,
    recommendation:
      riskLevel === 'Low'
        ? 'Recommend approval under standard terms.'
        : riskLevel === 'Medium'
        ? 'Recommend approval with additional review or adjusted terms (e.g. higher interest rate, guarantor).'
        : 'Recommend manual underwriter review before proceeding.'
  };
}

module.exports = { scoreApplicant };
